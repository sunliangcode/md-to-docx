# md-to-docx (Agensi skill package)

Turn **AI-generated Markdown** into **professional Word DOCX**—locally, with presets. No API keys.

**GitHub:** https://github.com/sunliangcode/md-to-docx

## Requirements

- Python 3.10+
- Runtime deps (once per machine):

```bash
pip install "markdown-it-py>=3" "mdit-py-plugins>=0.4" "python-docx>=1" "latex2mathml>=3" "lxml>=4.9"
```

## Convert in 10 seconds

```bash
# From this skill root (folder that contains SKILL.md)
./bin/convert examples/sample.md --preset technical --toc --numbering
```

Output: `examples/sample.docx` next to the source (source `.md` is never modified).

## Pick a preset

| User intent | Flag |
|-------------|------|
| Formal tech / design doc | `--preset technical --toc --numbering` |
| General document | `--preset professional` |
| Long-form / editorial | `--preset editorial` |
| Academic | `--preset academic` |
| Business summary | `--preset business` |
| Generic report | `--preset report` |

## More

- Agent instructions: [SKILL.md](SKILL.md)
- Presets: [references/presets.md](references/presets.md)
- MCP: [references/mcp.md](references/mcp.md)
- Reverse / diff: [references/roundtrip.md](references/roundtrip.md)
