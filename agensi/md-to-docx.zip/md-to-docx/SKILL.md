---
name: md-to-docx
description: >-
  Use when the user asks to convert Markdown to Word/DOCX, export an AI draft
  as a professional document, apply a technical/business/academic Word preset,
  reverse DOCX back to Markdown, or diff two document versions. Triggers:
  "markdown to word", "md to docx", "export report to Word", "make a DOCX",
  "format this as a technical report".
---

# md-to-docx

**AI / Markdown → professional Word.** Local compile. No API keys.  
**GitHub:** https://github.com/sunliangcode/md-to-docx

## What this skill does

When the user has Markdown (or an AI draft) and needs a deliverable `.docx`, you convert it with this package’s CLI—preserving headings, tables, code, callouts, and CJK-friendly layout via presets.

## Prerequisites (once)

Python 3.10+. If imports fail, install runtime deps (do **not** `pip install` this package itself when using the skill checkout):

```bash
pip install "markdown-it-py>=3" "mdit-py-plugins>=0.4" "python-docx>=1" "latex2mathml>=3" "lxml>=4.9"
```

## Agent workflow (do this every time)

1. Resolve **skill-root** = directory containing this `SKILL.md`.
2. Choose a preset from user intent:

   | Intent | Command flags |
   |--------|----------------|
   | Formal technical / design doc | `--preset technical --toc --numbering` |
   | General document | `--preset professional` |
   | Editorial / long-form | `--preset editorial` |
   | Academic paper | `--preset academic` |
   | Business summary | `--preset business` |
   | Generic report | `--preset report` |

3. Convert (never edit the source `.md`):

```bash
"<skill-root>/bin/convert" path/to/file.md --preset technical --toc --numbering
```

Fallback if `bin/convert` is unavailable:

```bash
PYTHONPATH="<skill-root>/scripts" python3 -m md_to_docx path/to/file.md --preset technical
```

4. Report the output `.docx` path to the user (default: beside the source file).
5. Optional Mermaid: if the markdown has ` ```mermaid ` blocks, ensure `mmdc` is on PATH or warn the user.
6. Reverse DOCX → MD: `PYTHONPATH="<skill-root>/scripts" python3 -m md_to_docx reverse file.docx -o file.md`
7. Diff two versions: `PYTHONPATH="<skill-root>/scripts" python3 -m md_to_docx diff v1.md v2.md --format md`

## Output contract

- Tell the user: input path, preset used, output `.docx` path, and any warnings (e.g. missing `mmdc`).
- Do not claim success if the command exited non-zero.

## Behavior

- Original `.md` files are never modified
- Output beside source unless `--output-dir`
- Callouts: `:::warning`, `:::info`, `:::note`
- Per-file failures reported; non-zero exit if any failed

## Troubleshooting

| Error | Fix |
|-------|-----|
| `No module named md_to_docx` | Use `bin/convert` or `PYTHONPATH=<skill-root>/scripts` |
| Missing `markdown-it-py` / `docx` | Run the `pip install` line above |
| `` `mmdc` not found `` | `npm i -g @mermaid-js/mermaid-cli` or remove mermaid blocks |

## Resources

- [Presets](references/presets.md)
- [MCP setup](references/mcp.md)
- [Reverse / diff](references/roundtrip.md)
- [Agents](references/agents.md)
