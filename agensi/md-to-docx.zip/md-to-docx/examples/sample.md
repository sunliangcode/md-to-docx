# Sample Technical Note

This sample verifies **md-to-docx** converts Markdown into a professional Word document.

## Why it matters

AI drafts land as Markdown. Stakeholders still need Word. This skill compiles the draft locally—no API keys.

## Checklist

| Item | Status |
|------|--------|
| Headings | OK |
| Tables | OK |
| Code | OK |

```python
def hello():
    return "docx ready"
```

> **Note:** Prefer `--preset technical --toc --numbering` for formal reports.

## Next step

Open the generated `.docx` beside this file and confirm formatting looks deliverable.
